package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation cho pattern 2 tick.
 *
 * Khác bản cũ:
 *  - Góc mới luôn nằm trên lưới sensitivity của chuột (gcd step), delta tính từ góc hiện tại.
 *    Không còn yaw/pitch "lệch lưới" → không bị AimModulo360 flag.
 *  - Lưu góc TRƯỚC khi apply (không dùng góc lúc đặt target), restore về góc mouse thật.
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static volatile Vec3d   pendingHitVec = null;
    private static volatile boolean applied       = false;
    private static volatile boolean hasPre        = false;
    private static volatile float   preYaw        = 0f;
    private static volatile float   prePitch      = 0f;

    public static void setPendingTarget(ClientPlayerEntity player, Vec3d hitVec) {
        pendingHitVec = hitVec;
        applied       = false;
        hasPre        = false;
    }

    public static boolean hasPendingTarget() { return pendingHitVec != null; }

    /** true chỉ khi beforeSync đã áp góc cho tick hiện tại. */
    public static boolean wasApplied() { return applied && pendingHitVec != null; }

    /** Áp góc snap lên player trước movement packet. */
    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (pendingHitVec == null) return false;
        if (!hasPre) {
            preYaw   = player.getYaw();
            prePitch = player.getPitch();
            hasPre   = true;
        }
        float[] rot = calcSnappedRotation(player, player.getEyePos(), pendingHitVec);
        applyRaw(player, rot);
        applied = true;
        return true;
    }

    public static void restoreAfterInteract(ClientPlayerEntity player) {
        pendingHitVec = null;
        applied       = false;
        if (player != null && hasPre) applyRaw(player, new float[]{ preYaw, prePitch });
        hasPre = false;
    }

    /** Bỏ target đang chờ và trả lại góc nhìn gốc. An toàn khi gọi nhiều lần. */
    public static void abort(ClientPlayerEntity player) {
        if (pendingHitVec != null) restoreAfterInteract(player);
        else applied = false;
    }

    public static void endOfTick() { applied = false; }

    // ─── KeyboardInputMixin ──────────────────────────────────────────────────

    public static float[] getPendingRot(ClientPlayerEntity player) {
        if (pendingHitVec == null) return null;
        return calcSnappedRotation(player, player.getEyePos(), pendingHitVec);
    }

    // ─── Lưới sensitivity ────────────────────────────────────────────────────

    /**
     * Bước góc nhỏ nhất mà chuột vanilla có thể tạo ra (degree).
     * Vanilla: f = sens*0.6+0.2; mouse → f^3*8 → yaw += 0.15 * that.
     * Verify lại nếu server/anticheat dùng công thức khác.
     */
    public static double gcdStep() {
        MinecraftClient mc = MinecraftClient.getInstance();
        double s = mc.options.getMouseSensitivity().getValue();
        double f = s * 0.6 + 0.2;
        return f * f * f * 8.0 * 0.15;
    }

    /**
     * Góc tới target, snap vào lưới chuột quanh góc hiện tại của player.
     * Delta yaw wrap về [-180,180] nên không nhảy 360 giữa các packet.
     */
    public static float[] calcSnappedRotation(ClientPlayerEntity player, Vec3d eye, Vec3d target) {
        float[] raw = calcRotationFromEye(eye, target);
        double  step = gcdStep();

        float curYaw   = player.getYaw();
        float curPitch = player.getPitch();

        double dYaw   = MathHelper.wrapDegrees(raw[0] - curYaw);
        double yaw    = curYaw + Math.round(dYaw / step) * step;

        double dPitch = raw[1] - curPitch;
        double pitch  = curPitch + Math.round(dPitch / step) * step;
        pitch = MathHelper.clamp(pitch, -90.0, 90.0);

        return new float[]{ (float) yaw, (float) pitch };
    }

    // ─── Math utils ──────────────────────────────────────────────────────────

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    public static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];
        player.bodyYaw = rot[0];
    }
}
