package com.firebow.event;

import com.firebow.FireBowClient;
import com.firebow.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v7 — HT1 cart: cart đặt ngay tick sau khi rail được gửi.
 *
 *   SEND  : chờ rotation tick này được áp → interact rail (tick N+1)
 *   CART  : tick N+2, rail đã hiện ở client → đặt TNT minecart NGAY (không chờ ping)
 *   WATCH : theo dõi rail trong khoảng ping/50 + 2 tick. Nếu server revert rail
 *           thì quay lại SEND, đặt lại rail rồi cart (tối đa MAX_PLACE_ATTEMPTS lần).
 *
 * Mọi thao tác đều chạy trên main thread (arrow tick + END_CLIENT_TICK).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_WAIT           = 3;   // tick chờ trước khi bỏ bước hiện tại
    private static final int  MAX_JOB_TICKS      = 80;  // hết giờ cho cả job

    private enum Phase { SEND, CART, WATCH }

    private static final class RailJob {
        final BlockPos pos;
        Phase phase      = Phase.SEND;
        int   attempts   = 0;  // số lần đã gửi interact rail
        int   ticks      = 0;  // tick đếm trong phase hiện tại
        int   window     = 0;  // số tick WATCH
        int   totalTicks = 0;

        RailJob(BlockPos pos) { this.pos = pos; }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private volatile boolean enabled = true;
    private RailJob job = null;  // chỉ đọc/ghi trên main thread
    private long predictedAt = 0L;  // lần cuối job được bắt đầu từ lúc thả cung

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── HEAD sendMovementPackets: áp góc để movement packet mang đúng rotation ──

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        RotationUtil.applyBeforeSync(mc.player);
    }

    // ─── Arrow tick: nhận yêu cầu đặt rail ──────────────────────────────────

    /** Bắt đầu job từ lúc thả cung (HT1 pre-charge). Không đợi mũi tên xuất hiện. */
    public void requestRailPredicted(MinecraftClient mc, BlockPos railPos) {
        if (job != null) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;
        if (InventoryUtil.findItem(Items.TNT_MINECART).isMissing()) return;

        predictedAt = System.currentTimeMillis();
        job = new RailJob(railPos);
        InteractionUtil.prepareRailPlacement(mc, railPos);
    }

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null) return;
        // Đã predict từ lúc thả cung → không đặt thêm rail/cart theo mũi tên thật
        if (System.currentTimeMillis() - predictedAt < 1500L) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);

        job = new RailJob(railPos);
        InteractionUtil.prepareRailPlacement(mc, railPos);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                RotationUtil.abort(null);
                return;
            }
            if (!enabled) {
                if (job != null) abort(mc, "disabled");
                return;
            }
            if (job != null) stepJob(mc);
        } finally {
            RotationUtil.endOfTick();
        }
    }

    private void stepJob(MinecraftClient mc) {
        // Người chơi bắt đầu kéo cung khác: hủy job, không đổi slot khi đang dùng item
        if (mc.player.isUsingItem()) { abort(mc, "using-item"); return; }

        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(mc, "timeout"); return; }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                if (railThere) {
                    // Rail đã có sẵn: không gửi interact nên phải xóa target đang chờ tại đây,
                    // nếu không beforeSync sẽ kéo góc nhìn về block rail mãi
                    RotationUtil.abort(mc.player);
                    enter(j, Phase.CART, 0);
                    return;
                }

                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(mc, "no-rail"); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> { j.attempts++; enter(j, Phase.CART, 0); }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(mc, "rail-not-ready"); }
                    case INVALID   -> abort(mc, "rail-invalid");
                }
            }

            case CART -> {
                if (!railThere) { revert(mc, j); return; }

                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { abort(mc, "no-cart"); return; }

                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    enter(j, Phase.WATCH, windowTicks(mc));
                } else if (j.ticks > MAX_WAIT) {
                    abort(mc, "cart-not-placed");
                }
            }

            case WATCH -> {
                if (!railThere) { revert(mc, j); return; }
                if (j.ticks >= j.window) finish(mc);
            }
        }
    }

    /** Server đã revert rail → đặt lại rail (và cart ở bước CART), hoặc bỏ nếu hết lượt. */
    private void revert(MinecraftClient mc, RailJob j) {
        if (j.attempts >= MAX_PLACE_ATTEMPTS) { abort(mc, "reverted-max"); return; }
        FireBowClient.LOGGER.debug("[FireBow] rail reverted at {}, attempt {}", j.pos, j.attempts);
        InteractionUtil.prepareRailPlacement(mc, j.pos);
        enter(j, Phase.SEND, 0);
    }

    private static void enter(RailJob j, Phase phase, int window) {
        j.phase  = phase;
        j.ticks  = 0;
        j.window = window;
    }

    private void abort(MinecraftClient mc, String why) {
        FireBowClient.LOGGER.debug("[FireBow] job abort: {}", why);
        job = null;
        InteractionUtil.abort(mc);
    }

    /** Job xong bình thường: luôn trả góc nhìn về mouse thật. */
    private void finish(MinecraftClient mc) {
        job = null;
        RotationUtil.abort(mc == null ? null : mc.player);
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }

    /** Ping/50ms + 2 tick đệm: khoảng theo dõi để phát hiện revert từ server. */
    private static int windowTicks(MinecraftClient mc) {
        long ping = PingUtil.getPingMs(mc);
        return (int) Math.max(2, Math.ceil(ping / 50.0) + 2);
    }
}
